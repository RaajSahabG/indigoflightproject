import React, { useState } from 'react';
import axios from 'axios';

const Notification = () => {
  const [message, setMessage] = useState('');

  const sendNotification = async () => {
    const response = await axios.post('/api/send-notification', {
      message,
      type: 'info',  // For simplicity, setting type as 'info'. Can be dynamic.
    });
    console.log(response.data);
  };

  return (
    <div>
      <h2>Send Notification</h2>
      <input 
        type="text" 
        value={message} 
        onChange={(e) => setMessage(e.target.value)} 
        placeholder="Enter Notification Message" 
      />
      <button onClick={sendNotification}>Send</button>
    </div>
  );
};

export default Notification;
