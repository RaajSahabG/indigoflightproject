# Flight Status and Notifications

This project is a full-stack web application that provides real-time flight status updates and notifications to passengers. The application includes a frontend built with React.js, a backend built with FastAPI, and a database using MongoDB. Notifications can be sent via SMS, email, or app notifications using Kafka or RabbitMQ.

## Features

1. **Real-time Updates**: Display current flight status (delays, cancellations, gate changes).
2. **Push Notifications**: Send notifications for flight status changes via SMS, email, or app notifications.
3. **Integration with Airport Systems**: Pull data from airport databases for accurate information.

## Technologies Used

- **Frontend**: HTML, CSS, React.js
- **Backend**: FastAPI (Python)
- **Database**: MongoDB
- **Notifications**: Kafka, RabbitMQ

## Prerequisites

- Node.js
- Python 3.8+
- MongoDB
- Kafka or RabbitMQ

## Setup

### Backend

1. **Clone the Repository**

   ```bash
   git clone https://github.com/your-username/flight-status-notifications.git
   cd flight-status-notifications/backend
