import requests

async def get_flight_status(flight_id: str):
    # Mocking the data retrieval from airport database
    response = requests.get(f"http://mock_airport_api.com/status/{flight_id}")
    return response.json()
