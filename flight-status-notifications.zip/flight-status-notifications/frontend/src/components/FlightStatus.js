import React, { useState, useEffect } from 'react';
import axios from 'axios';

const FlightStatus = () => {
  const [flightId, setFlightId] = useState('');
  const [status, setStatus] = useState(null);

  const fetchStatus = async () => {
    const response = await axios.get(`/api/flight-status/${flightId}`);
    setStatus(response.data);
  };

  return (
    <div>
      <h2>Check Flight Status</h2>
      <input 
        type="text" 
        value={flightId} 
        onChange={(e) => setFlightId(e.target.value)} 
        placeholder="Enter Flight ID" 
      />
      <button onClick={fetchStatus}>Check Status</button>
      {status && (
        <div>
          <h3>Status: {status.status}</h3>
          <p>Details: {status.details}</p>
        </div>
      )}
    </div>
  );
};

export default FlightStatus;
