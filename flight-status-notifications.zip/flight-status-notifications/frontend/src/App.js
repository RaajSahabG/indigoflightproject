import React, { useState } from 'react';
import FlightStatus from './components/FlightStatus';
import Notification from './components/Notification';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Flight Status and Notifications</h1>
      <FlightStatus />
      <Notification />
    </div>
  );
}

export default App;
