import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
});

export const getFlightStatus = (flightId) => api.get(`/flight-status/${flightId}`);
export const sendNotification = (notification) => api.post('/send-notification', notification);
