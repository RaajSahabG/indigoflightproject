import requests

async def send_notification(notification: dict):
    # Mocking the sending of notification using Firebase Cloud Messaging
    response = requests.post("https://fcm.googleapis.com/fcm/send", json=notification)
    return response.json()
