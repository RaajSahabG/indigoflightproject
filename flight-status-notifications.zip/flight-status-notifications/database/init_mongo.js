// MongoDB initialization script
db.createUser({
    user: 'user',
    pwd: 'password',
    roles: [
      {
        role: 'readWrite',
        db: 'flightdb'
      }
    ]
  });
  
  db.createCollection('flights');
  