from fastapi import APIRouter
from app.services.flight_status_service import get_flight_status
from app.services.notification_service import send_notification

router = APIRouter()

@router.get("/flight-status/{flight_id}")
async def flight_status(flight_id: str):
    return await get_flight_status(flight_id)

@router.post("/send-notification")
async def notify(notification: dict):
    return await send_notification(notification)
